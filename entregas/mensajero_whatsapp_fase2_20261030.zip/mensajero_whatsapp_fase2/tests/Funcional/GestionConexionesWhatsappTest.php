<?php

namespace Tests\Funcional;

use Tests\TestCase;

class GestionConexionesWhatsappTest extends TestCase
{
    public function test_cambios_y_qr_fallan_cerrados_sin_autenticacion(): void
    {
        config()->set('mensajero.autenticacion.modo', 'deshabilitado');

        $this->get('/administracion/whatsapp/conexiones/1/estado')->assertStatus(403);
        $this->post('/administracion/whatsapp/conexiones/1/iniciar')->assertStatus(403);
        $this->post('/administracion/whatsapp/conexiones/1/detener')->assertStatus(403);
    }

    public function test_sin_sesion_en_modo_local_se_redirige_al_acceso(): void
    {
        config()->set('mensajero.autenticacion.modo', 'local');

        $this->get('/administracion/whatsapp/conexiones/1/estado')->assertRedirect(route('acceso'));
        $this->post('/administracion/whatsapp/conexiones/1/iniciar')->assertRedirect(route('acceso'));
        $this->post('/administracion/whatsapp/conexiones/1/detener')->assertRedirect(route('acceso'));
    }
}
