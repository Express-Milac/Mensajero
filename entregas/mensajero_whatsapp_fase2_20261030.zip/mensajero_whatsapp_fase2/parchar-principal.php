<?php

if ($argc !== 2) {
    fwrite(STDERR, "Uso: php parchar-principal.php ruta-principal.ts\n");
    exit(1);
}

$ruta = $argv[1];
$codigo = file_get_contents($ruta);
if ($codigo === false) {
    exit("No se pudo leer principal.ts\n");
}

$anclaQr = '    alQr: (qr) => {';
$anclaEstado = '      estadoActual = estado;';
$anclaEnviar = '      await encolarEstado(estado, detalles);';

foreach ([$anclaQr, $anclaEstado, $anclaEnviar] as $ancla) {
    if (substr_count($codigo, $ancla) !== 1) {
        exit("Estructura inesperada del recolector; cambio cancelado.\n");
    }
}

if (strpos($codigo, 'MENSAJERO_SUPERVISADO') !== false || strpos($codigo, "tipo: 'qr'") !== false) {
    exit("El recolector ya parece estar adaptado; se cancela para no duplicar cambios.\n");
}

$codigo = str_replace($anclaQr, $anclaQr."\n".
    "      if (typeof process.send === 'function' && process.env.MENSAJERO_SUPERVISADO === '1') {\n".
    "        process.send({ tipo: 'qr', valor: qr });\n".
    "        return;\n".
    "      }", $codigo);

$codigo = str_replace($anclaEnviar,
    "      if (typeof process.send === 'function' && process.env.MENSAJERO_SUPERVISADO === '1') {\n".
    "        process.send({ tipo: 'estado', estado });\n".
    "      }\n".
    $anclaEnviar, $codigo);

if (file_put_contents($ruta, $codigo, LOCK_EX) === false) {
    exit("No se pudo modificar principal.ts\n");
}

echo "PRINCIPAL_ADAPTADO_PARA_IPC=SI\n";
