# Mensajero Milac — Fase 2: vinculación web y gestor de múltiples conexiones

**Estado:** paquete de integración para pruebas en el servidor Milac; no equivale a haber desplegado o iniciado el servicio.

## Qué contiene

- Rutas administrativas autenticadas para iniciar, detener y consultar el estado de cada línea.
- QR generado por Baileys, transferido por IPC al supervisor y representado como PNG temporal en la página de Laravel. No se persiste el QR.
- Supervisor Node.js exclusivo de `127.0.0.1:8787`, con protocolo HMAC diferenciado (`gestor-v1`), firma por petición y protección de repetición.
- Trabajador independiente por línea que reutiliza íntegramente el recolector y sus colas durables. Cada trabajador recibe `MENSAJERO_CLAVE_CONEXION` y `RECOLECTOR_RUTA_DATOS` independientes.
- Endpoint Laravel firmado que permite recuperar al reiniciar las líneas marcadas como habilitadas.
- Adaptación mínima y reversible de `principal.ts` para entregar QR y estado por IPC en lugar de imprimir el QR en la terminal supervisada.
- Pruebas negativas de acceso y de firmas HMAC; se preservan las pruebas existentes del recolector.
- Enlace administrativo en el menú solo si se reconoce el ancla original. Si la navegación fue modificada, se omite sin sobrescribirla.

## Aplicación

El instalador no ejecuta migraciones ni inicia sesiones. Antes de instalar, revisar la autenticación efectiva y que la Fase 1 ya esté instalada. El servidor necesita acceso a npm para incorporar `qrcode` y `@types/qrcode`, utilizados solo para representar el QR como PNG sin servicios externos. El gestor de sesiones debe ejecutarse como servicio independiente, con **un único supervisor** y acceso local; no lanzar varios supervisores. 

1. Transferir el `.tar.gz` a `/tmp` y verificar SHA256.
2. Descomprimir en directorio temporal.
3. Ejecutar `bash instalar-fase2.sh`.
4. El instalador guarda respaldo privado de rutas, layout, vista, `principal.ts`, `package.json` y `package-lock.json`, copia archivos **solo si no existen**, aplica las adaptaciones a `principal.ts`, agrega rutas y compila/ejecuta pruebas.
5. Si falla, revierte las modificaciones a los archivos existentes y elimina los archivos nuevos. Puede quedar una copia de los nuevos paquetes npm dentro de `node_modules`, que es reversible con `npm ci` usando el `package-lock` restaurado.
6. **No arrancar el gestor** hasta comprobar pruebas, modo de autenticación, acceso 403 sin sesión, disponibilidad de puerto y permisos de directorios. Después se configura un servicio permanente bajo usuario `sistemas`.

## Contrato de servicio

- Node.js: `node dist/src/gestor.js`, con directorio de trabajo `recolector-whatsapp`, `.env` de recolector y Node.js 22 aislado.
- HTTP: `127.0.0.1:8787` exclusivamente, nunca publicar en Apache, Cloudflare o Internet.
- Firma: HMAC-SHA256 con `WHATSAPP_PASARELA_SECRETO` / `MENSAJERO_PASARELA_SECRETO`, cadena canónica `gestor-v1\n{id}\n{timestamp}\n{sha256(cuerpo)}`, encabezados `X-Mensajero-Gestor-Id`, `-Marca` y `-Firma`.
- Recursos: límite por defecto de 3 líneas simultáneas; ajustable por `MENSAJERO_GESTOR_MAX_SESIONES` previa medición de memoria del servidor.
- Conexiones: `/home/sistemas/.local/share/mensajero/recolector/conexiones/<id>/sesion` con modo de acceso privado; colas y autorizaciones quedan en la misma carpeta segregada.
- Multimedia: permanece en el mismo almacenamiento privado compartido por Laravel, con separación lógica por clave de conexión existente.
- El reinicio del gestor recupera únicamente líneas con `metadatos.vinculacion_habilitada === true`, tras consulta firmada a Laravel. Si Laravel está inaccesible, no elimina sesiones.

## Limitaciones y siguientes validaciones

- **La instalación no inicia WhatsApp**. Hace falta servicio persistente y una sesión de prueba.
- La autenticación corporativa debe funcionar y autorizar a administradores. Con modo deshabilitado, las rutas mutables quedan bloqueadas.
- Los grupos **no se autorizan** automáticamente; se habilitan en el Gestor de grupos existente.
- La pausa conserva los archivos de sesión y la cola. La desvinculación definitiva, la auditoría de acciones administrativas y la recuperación exhaustiva ante corte simultáneo de proceso/SQL Server deben desarrollarse y probarse antes de declarar funcionalidad terminada.
- Si una cuenta se vincula y luego expira, Baileys puede exigir renovación y manejo cuidadoso de credenciales; no borrar carpetas automáticamente.
- Deben probarse aislamientos con dos cuentas de prueba reales sin afectar números principales de Milac.
- Usar *una sola* instancia del supervisor; el puerto fijo evita dos instancias iguales en el mismo host, pero hay que asegurar que no existan recolectores legados ejecutándose por separado.

## Servicio persistente

El paquete incluye una **plantilla** `operacion/mensajero-gestor.service`, que no se instala ni habilita automáticamente. Una persona autorizada para administrar `systemd` en `webserver` deberá revisarla antes de instalarla. No debe arrancarse el gestor hasta que la autenticación y todas las pruebas hayan pasado. No publicar el puerto 8787 y no reutilizar el puerto del canal SSE 8765.
