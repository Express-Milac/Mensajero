<?php

use App\Http\Controllers\Pasarela\ControladorConexionesHabilitadas;
use Illuminate\Support\Facades\Route;

Route::post('/pasarela/v1/conexiones-habilitadas', [ControladorConexionesHabilitadas::class, 'indice'])
    ->middleware(['mensajero.firma_pasarela:no', 'throttle:30,1'])
    ->name('pasarela.v1.conexiones.habilitadas');
