<?php

use App\Http\Controllers\Administracion\ControladorGestionWhatsapp;
use Illuminate\Support\Facades\Route;

Route::prefix('administracion/whatsapp')
    ->middleware('mensajero.acceso:administrador')
    ->name('whatsapp.gestion.')
    ->group(function (): void {
        Route::post('/conexiones/{conexion}/iniciar', [ControladorGestionWhatsapp::class, 'iniciar'])
            ->whereNumber('conexion')->middleware('throttle:10,1')->name('iniciar');
        Route::post('/conexiones/{conexion}/detener', [ControladorGestionWhatsapp::class, 'detener'])
            ->whereNumber('conexion')->middleware('throttle:10,1')->name('detener');
        Route::get('/conexiones/{conexion}/estado', [ControladorGestionWhatsapp::class, 'estado'])
            ->whereNumber('conexion')->middleware('throttle:300,1')->name('estado');
    });
