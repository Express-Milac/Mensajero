<?php
if ($argc !== 2) { exit("Uso: php parchar-navegacion.php ruta-layout\n"); }
$ruta = $argv[1];
$contenido = file_get_contents($ruta);
if ($contenido === false) { exit("No se pudo leer el menú\n"); }
if (strpos($contenido, "route('whatsapp.conexiones.indice')") !== false) {
    echo "NAVEGACION=YA_EXISTE\n";
    exit(0);
}
$ancla = "href=\"{{ route('grupos.indice') }}\"";
if (substr_count($contenido, $ancla) !== 1) {
    echo "NAVEGACION=OMITIDA_ANCLA_MODIFICADA\n";
    exit(0);
}
$inicio = strpos($contenido, $ancla);
$fin = strpos($contenido, '</a>', $inicio);
if ($fin === false || $fin - $inicio > 650) {
    echo "NAVEGACION=OMITIDA_ESTRUCTURA_MODIFICADA\n";
    exit(0);
}
$fin += strlen('</a>');
$nuevo = <<<'BLADE'

                    @if(config('mensajero.autenticacion.modo') !== 'deshabilitado' && auth()->check() && auth()->user()->can('administrar'))
                        <a class="nav {{ request()->routeIs('whatsapp.*') ? 'active' : '' }}" href="{{ route('whatsapp.conexiones.indice') }}">
                            <span>Conexiones de WhatsApp</span>
                        </a>
                    @endif
BLADE;
$contenido = substr($contenido, 0, $fin).$nuevo.substr($contenido, $fin);
if (file_put_contents($ruta, $contenido, LOCK_EX) === false) { exit("No se pudo modificar el menú\n"); }
echo "NAVEGACION=AGREGADA\n";
