#!/usr/bin/env bash
# Prepara Fase 2 sin iniciar el gestor ni conectar ninguna cuenta.
set -Eeuo pipefail
umask 077
raiz=/home/sistemas/laravelProjects/Mensajero
origen="$(cd "$(dirname "$0")" && pwd)"
cd "$raiz"

if [[ ! -f routes/administracion_whatsapp.php ]]; then
  echo 'ERROR=PRIMERO_INSTALAR_FASE1' >&2; exit 1
fi
if [[ ! -f recolector-whatsapp/package-lock.json ]]; then
  echo 'ERROR=FALTA_PACKAGE_LOCK' >&2; exit 1
fi
if ! command -v python3 >/dev/null 2>&1; then
  echo 'ERROR=PYTHON3_REQUERIDO_PARA_PREVENCION_DE_DUPLICADOS' >&2; exit 1
fi
node_bin="$HOME/.local/opt/mensajero-node-v22.23.4/bin"
if [[ ! -x "$node_bin/node" ]]; then
  echo 'ERROR=NODE22_AISLADO_NO_ENCONTRADO' >&2; exit 1
fi
export PATH="$node_bin:$PATH"
hash -r

nuevos=(
  app/Services/WhatsApp/ClienteGestorWhatsapp.php
  app/Http/Controllers/Administracion/ControladorGestionWhatsapp.php
  app/Http/Controllers/Pasarela/ControladorConexionesHabilitadas.php
  routes/administracion_whatsapp_gestion.php
  routes/administracion_whatsapp_api.php
  recolector-whatsapp/src/gestion/protocolo.ts
  recolector-whatsapp/src/gestion/gestor-conexiones.ts
  recolector-whatsapp/src/gestor.ts
  recolector-whatsapp/tests/gestor-protocolo.test.ts
  tests/Funcional/GestionConexionesWhatsappTest.php
)
for archivo in "${nuevos[@]}"; do
  [[ -f "$origen/$archivo" ]] || { echo "FALTA_ORIGEN=$archivo" >&2; exit 1; }
  [[ ! -e "$archivo" ]] || { echo "YA_EXISTE_NO_SE_SOBRESCRIBE=$archivo" >&2; exit 1; }
done

# La vista de Fase 1 es idéntica a la entregada. Si hubo ediciones, no sobrescribir.
esperado=c8af4b9d3f998d0e7a20f18e9ba7be8268f00f188764594c3b8cb893337d38e6
actual="$(sha256sum resources/views/administracion/whatsapp/indice.blade.php | awk '{print $1}')"
if [[ "$esperado" != "$actual" ]]; then
  echo 'ERROR=VISTA_FASE1_MODIFICADA_INSTALACION_CANCELADA' >&2
  exit 1
fi

for ancla in "require __DIR__.'/administracion_whatsapp_gestion.php';"; do
  if grep -Fq "$ancla" routes/web.php; then echo 'ERROR=RUTAS_GESTION_YA_REGISTRADAS' >&2; exit 1; fi
done
if grep -Fq "require __DIR__.'/administracion_whatsapp_api.php';" routes/api.php; then
  echo 'ERROR=RUTAS_API_YA_REGISTRADAS' >&2; exit 1
fi

# No interferir con sesiones ya activas.
if ps -eo args | grep -E '[n]ode .*recolector-whatsapp/(dist/src/principal.js|dist/src/gestor.js)' >/dev/null; then
  echo 'ERROR=RECOLECTOR_EN_EJECUCION' >&2; exit 1
fi

respaldo="$(mktemp -d "$HOME/.mensajero-fase2-respaldo.XXXXXX")"
chmod 700 "$respaldo"
mkdir -p "$respaldo/recolector-whatsapp/src" "$respaldo/recolector-whatsapp" "$respaldo/routes" "$respaldo/resources/views/administracion/whatsapp" "$respaldo/resources/views/components"
for archivo in routes/web.php routes/api.php \
   resources/views/components/layout.blade.php \
   recolector-whatsapp/src/principal.ts \
   recolector-whatsapp/package.json \
   recolector-whatsapp/package-lock.json \
   resources/views/administracion/whatsapp/indice.blade.php; do
  cp -p "$archivo" "$respaldo/$archivo"
done

echo "RESPALDO=$respaldo"
instalados=()
revertir() {
  codigo=$?
  if [[ "$codigo" -ne 0 ]]; then
    echo 'ERROR=FASE2_SE_REVIRTIERON_ARCHIVOS' >&2
    for archivo in routes/web.php routes/api.php \
        resources/views/components/layout.blade.php \
        recolector-whatsapp/src/principal.ts \
        recolector-whatsapp/package.json \
        recolector-whatsapp/package-lock.json \
        resources/views/administracion/whatsapp/indice.blade.php; do
      cp -p "$respaldo/$archivo" "$archivo"
    done
    for archivo in "${instalados[@]}"; do rm -f "$archivo"; done
    (cd recolector-whatsapp && npm ci --ignore-scripts --no-audit --no-fund) || true
  fi
}
trap revertir EXIT

for archivo in "${nuevos[@]}"; do
  mkdir -p "$(dirname "$archivo")"
  cp "$origen/$archivo" "$archivo"
  chmod 644 "$archivo"
  instalados+=("$archivo")
done
cp "$origen/resources/views/administracion/whatsapp/indice.blade.php" \
  resources/views/administracion/whatsapp/indice.blade.php
chmod 644 resources/views/administracion/whatsapp/indice.blade.php
php "$origen/parchar-principal.php" recolector-whatsapp/src/principal.ts
php "$origen/parchar-navegacion.php" resources/views/components/layout.blade.php

printf '\n// Gestión de sesiones WhatsApp (solo administrador).\nrequire __DIR__.'"'"'/administracion_whatsapp_gestion.php'"'"';\n' >> routes/web.php
printf '\n// Descubrimiento firmado de conexiones habilitadas.\nrequire __DIR__.'"'"'/administracion_whatsapp_api.php'"'"';\n' >> routes/api.php

for archivo in "${nuevos[@]}"; do
  if [[ "$archivo" == *.php ]]; then php -l "$archivo" >/dev/null; fi
done
php -l routes/web.php >/dev/null
php -l routes/api.php >/dev/null

cd recolector-whatsapp
npm install --ignore-scripts --save-exact --no-audit --no-fund qrcode@1.5.4
npm install --ignore-scripts --save-dev --save-exact --no-audit --no-fund @types/qrcode@1.5.5
npm run verificar
npm run pruebas
npm run construir
cd "$raiz"

php artisan route:list --path=administracion/whatsapp | grep -F 'whatsapp.gestion.estado' >/dev/null
php artisan route:list --path=api/pasarela | grep -F 'pasarela.v1.conexiones.habilitadas' >/dev/null
if [[ -x vendor/bin/phpunit ]]; then
  vendor/bin/phpunit tests/Funcional/AdministracionConexionesWhatsappTest.php
  vendor/bin/phpunit tests/Funcional/GestionConexionesWhatsappTest.php
else
  echo 'AVISO=PHPUNIT_NO_DISPONIBLE'
fi

echo 'FASE2_ARCHIVOS_Y_RUTAS=INSTALADOS'
echo 'FASE2_COMPILACION_Y_PRUEBAS=CORRECTAS'
echo 'GESTOR=NO_INICIADO'
echo 'WHATSAPP=NO_CONECTADO'
echo "RESPALDO=$respaldo"
