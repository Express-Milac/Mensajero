import { fork, type ChildProcess } from 'node:child_process';
import { createServer, type Server, type IncomingMessage, type ServerResponse } from 'node:http';
import { join, resolve } from 'node:path';
import { mkdir } from 'node:fs/promises';
import QRCode from 'qrcode';
import { ClienteMensajero } from '../cliente-mensajero.js';
import { autorizarGestor } from './protocolo.js';

type Estado = 'sin_iniciar' | 'conectando' | 'requiere_vinculacion' | 'conectado' | 'desconectado' | 'error';
interface ConexionRemota { id: number; clave_conexion: string }
interface HijoConexion {
  hijo: ChildProcess;
  clave: string;
  estado: Estado;
  qrImagen: string | null;
  qrVence: number;
  inicio: number;
  detenido: boolean;
}

function numeroId(valor: string): number | null {
  if (!/^[1-9][0-9]{0,12}$/.test(valor)) return null;
  const id = Number(valor);
  return Number.isSafeInteger(id) ? id : null;
}

export class GestorConexiones {
  private readonly hijos = new Map<number, HijoConexion>();
  private readonly usados = new Map<string, number>();
  private servidor: Server | null = null;
  private intervalo: NodeJS.Timeout | null = null;
  private cerrando = false;
  private sincronizando = false;
  private readonly maximo: number;

  public constructor(
    private readonly url: string,
    private readonly secreto: string,
    private readonly rutaDatos: string,
    private readonly puerto = 8787,
  ) {
    const maximo = Number(process.env.MENSAJERO_GESTOR_MAX_SESIONES ?? '3');
    if (!Number.isInteger(maximo) || maximo < 1 || maximo > 12) {
      throw new Error('MENSAJERO_GESTOR_MAX_SESIONES debe estar entre 1 y 12.');
    }
    this.maximo = maximo;
  }

  public async iniciarServidor(): Promise<void> {
    if (this.servidor) throw new Error('El gestor ya se inició.');
    await mkdir(join(this.rutaDatos, 'conexiones'), { recursive: true, mode: 0o700 });
    const servidor = createServer((peticion, respuesta) => {
      void this.atender(peticion, respuesta).catch(() => {
        if (!respuesta.headersSent) this.responder(respuesta, 500, { mensaje: 'Error interno del gestor.' });
        else respuesta.end();
      });
    });
    servidor.requestTimeout = 6_000;
    servidor.headersTimeout = 5_000;
    servidor.maxConnections = 16;
    await new Promise<void>((resolver, rechazar) => {
      servidor.once('error', rechazar);
      servidor.listen(this.puerto, '127.0.0.1', resolver);
    });
    this.servidor = servidor;
    this.intervalo = setInterval(() => { void this.sincronizarConLaravel(); }, 60_000);
    void this.sincronizarConLaravel();
  }

  private responder(respuesta: ServerResponse, estado: number, datos: Record<string, unknown>): void {
    respuesta.writeHead(estado, {
      'Content-Type': 'application/json; charset=utf-8',
      'Cache-Control': 'private, no-store, max-age=0',
      'X-Content-Type-Options': 'nosniff',
    });
    respuesta.end(JSON.stringify(datos));
  }

  private async atender(peticion: IncomingMessage, respuesta: ServerResponse): Promise<void> {
    if (peticion.socket.remoteAddress !== '127.0.0.1'
      && peticion.socket.remoteAddress !== '::ffff:127.0.0.1') {
      this.responder(respuesta, 403, { mensaje: 'Origen no autorizado.' });
      return;
    }

    let cuerpo = '';
    for await (const parte of peticion) {
      cuerpo += parte.toString('utf8');
      if (Buffer.byteLength(cuerpo, 'utf8') > 4096) {
        this.responder(respuesta, 413, { mensaje: 'Solicitud demasiado grande.' });
        return;
      }
    }

    const encabezado = (nombre: string): string | undefined => {
      const valor = peticion.headers[nombre];
      return typeof valor === 'string' ? valor : undefined;
    };
    if (!autorizarGestor(
      encabezado('x-mensajero-gestor-id'),
      encabezado('x-mensajero-gestor-marca'),
      encabezado('x-mensajero-gestor-firma'),
      cuerpo, this.secreto, this.usados,
    )) {
      this.responder(respuesta, 401, { mensaje: 'Firma de gestión inválida.' });
      return;
    }

    const ruta = peticion.url ?? '';
    const coincidencia = /^\/v1\/conexiones\/([1-9][0-9]*)(?:\/(iniciar|detener))?$/.exec(ruta);
    if (!coincidencia) {
      this.responder(respuesta, 404, { mensaje: 'Ruta desconocida.' });
      return;
    }
    const id = numeroId(coincidencia[1] ?? '');
    if (id === null) {
      this.responder(respuesta, 422, { mensaje: 'Identificador inválido.' });
      return;
    }
    const accion = coincidencia[2] ?? '';

    if (peticion.method === 'GET' && accion === '') {
      const registro = this.hijos.get(id);
      this.responder(respuesta, 200, registro ? {
        estado: registro.estado,
        qr_imagen: registro.qrVence > Date.now() && registro.estado === 'requiere_vinculacion'
          ? registro.qrImagen : null,
        qr_vigente: registro.qrVence > Date.now() && registro.estado === 'requiere_vinculacion',
      } : { estado: 'sin_iniciar', qr_imagen: null, qr_vigente: false });
      return;
    }

    if (peticion.method === 'POST' && accion === 'iniciar') {
      let datos: unknown;
      try { datos = JSON.parse(cuerpo); } catch { datos = null; }
      const clave = typeof datos === 'object' && datos !== null && 'clave_conexion' in datos
        ? (datos as Record<string, unknown>).clave_conexion : null;
      if (typeof clave !== 'string' || !/^[a-zA-Z0-9_-]{12,64}$/.test(clave)) {
        this.responder(respuesta, 422, { mensaje: 'Clave de conexión inválida.' });
        return;
      }
      try {
        await this.iniciarConexion(id, clave);
        this.responder(respuesta, 202, { estado: 'iniciada' });
      } catch (error) {
        this.responder(respuesta, 409, { mensaje: error instanceof Error ? error.message : 'No se pudo iniciar.' });
      }
      return;
    }

    if (peticion.method === 'POST' && accion === 'detener') {
      try {
        await this.detenerConexion(id);
        this.responder(respuesta, 200, { estado: 'detenida' });
      } catch {
        this.responder(respuesta, 503, { mensaje: 'No se pudo detener la línea.' });
      }
      return;
    }
    this.responder(respuesta, 405, { mensaje: 'Método no permitido.' });
  }

  private async iniciarConexion(id: number, clave: string): Promise<void> {
    const actual = this.hijos.get(id);
    if (actual) {
      if (actual.clave !== clave) throw new Error('La conexión registrada tiene una clave diferente.');
      return;
    }
    if (this.hijos.size >= this.maximo) throw new Error('Se alcanzó el límite de líneas simultáneas.');
    if (this.cerrando) throw new Error('El gestor se está deteniendo.');

    const carpeta = resolve(this.rutaDatos, 'conexiones', String(id));
    await mkdir(carpeta, { recursive: true, mode: 0o700 });
    const ejecutable = resolve(process.cwd(), 'dist/src/principal.js');
    const hijo = fork(ejecutable, [], {
      cwd: process.cwd(),
      execPath: process.execPath,
      stdio: ['ignore', 'inherit', 'inherit', 'ipc'],
      env: {
        ...process.env,
        MENSAJERO_CLAVE_CONEXION: clave,
        RECOLECTOR_RUTA_DATOS: carpeta,
        MENSAJERO_TIEMPO_REAL_PUERTO: '0',
        MENSAJERO_SUPERVISADO: '1',
      },
    });
    const registro: HijoConexion = {
      hijo, clave, estado: 'conectando', qrImagen: null, qrVence: 0, inicio: Date.now(), detenido: false,
    };
    this.hijos.set(id, registro);
    hijo.on('message', (mensaje: unknown) => {
      void this.manejarMensaje(id, registro, mensaje);
    });
    hijo.on('exit', (codigo, senal) => {
      if (this.hijos.get(id) === registro) {
        this.hijos.delete(id);
        // El siguiente ciclo de conciliación restaurará solo las líneas habilitadas.
        if (!registro.detenido && !this.cerrando) {
          process.stderr.write(`[Gestor] Trabajador ${id} finalizó (código=${codigo ?? ''}, señal=${senal ?? ''}).\n`);
        }
      }
    });
  }

  private async manejarMensaje(id: number, registro: HijoConexion, mensaje: unknown): Promise<void> {
    if (this.hijos.get(id) !== registro || !mensaje || typeof mensaje !== 'object') return;
    const datos = mensaje as Record<string, unknown>;
    if (datos.tipo === 'estado' && typeof datos.estado === 'string'
      && ['conectando', 'requiere_vinculacion', 'conectado', 'desconectado', 'error'].includes(datos.estado)) {
      registro.estado = datos.estado as Estado;
      if (registro.estado === 'conectado') { registro.qrImagen = null; registro.qrVence = 0; }
    }
    if (datos.tipo === 'qr' && typeof datos.valor === 'string' && datos.valor.length <= 8192) {
      try {
        const qrImagen = await QRCode.toDataURL(datos.valor, { width: 300, margin: 3, errorCorrectionLevel: 'M' });
        if (this.hijos.get(id) !== registro) return;
        registro.qrImagen = qrImagen;
        registro.qrVence = Date.now() + 30_000;
        registro.estado = 'requiere_vinculacion';
      } catch {
        registro.qrImagen = null;
      }
    }
  }

  private async detenerConexion(id: number): Promise<void> {
    const registro = this.hijos.get(id);
    if (!registro) return;
    registro.detenido = true;
    registro.qrImagen = null;
    registro.qrVence = 0;
    if (registro.hijo.exitCode !== null) {
      this.hijos.delete(id);
      return;
    }
    const finalizo = new Promise<boolean>((resolver) => {
      const tiempo = setTimeout(() => resolver(false), 8_000);
      registro.hijo.once('exit', () => { clearTimeout(tiempo); resolver(true); });
    });
    registro.hijo.kill('SIGTERM');
    if (!await finalizo) throw new Error('El trabajador no se detuvo en el plazo esperado.');
    this.hijos.delete(id);
  }

  private async sincronizarConLaravel(): Promise<void> {
    if (this.sincronizando || this.cerrando) return;
    this.sincronizando = true;
    try {
      const cliente = new ClienteMensajero(this.url, this.secreto, '');
      const respuesta = await cliente.enviar<{ conexiones: ConexionRemota[] }>(
        '/api/pasarela/v1/conexiones-habilitadas', {},
      );
      if (!respuesta || !Array.isArray(respuesta.conexiones)) throw new Error('Listado inválido.');
      const activos = new Map<number, string>();
      for (const dato of respuesta.conexiones) {
        if (numeroId(String(dato.id)) !== dato.id ||
          typeof dato.clave_conexion !== 'string' || !/^[a-zA-Z0-9_-]{12,64}$/.test(dato.clave_conexion)) {
          throw new Error('El servidor devolvió conexiones inválidas.');
        }
        activos.set(dato.id, dato.clave_conexion);
      }
      for (const [id] of this.hijos) {
        if (!activos.has(id)) await this.detenerConexion(id);
      }
      for (const [id, clave] of activos) {
        if (!this.hijos.has(id)) {
          try { await this.iniciarConexion(id, clave); }
          catch (error) {
            process.stderr.write(`[Gestor] No se pudo iniciar la línea ${id}: ${error instanceof Error ? error.message : 'error'}.\n`);
          }
        }
      }
    } catch {
      // Si Laravel no responde, conservar sesiones. Nunca interpretar un fallo como revocación.
      process.stderr.write('[Gestor] No se pudo conciliar el estado; se conservarán las sesiones.\n');
    } finally {
      this.sincronizando = false;
    }
  }

  public async detener(): Promise<void> {
    this.cerrando = true;
    if (this.intervalo) clearInterval(this.intervalo);
    await Promise.allSettled([...this.hijos.keys()].map((id) => this.detenerConexion(id)));
    await new Promise<void>((resolver) => {
      if (!this.servidor) return resolver();
      this.servidor.close(() => resolver());
    });
    this.servidor = null;
  }
}
