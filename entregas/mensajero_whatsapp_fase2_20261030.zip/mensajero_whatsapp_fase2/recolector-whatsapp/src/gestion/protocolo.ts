import { createHash, createHmac, randomUUID, timingSafeEqual } from 'node:crypto';

export function firmarGestor(identificador: string, marca: string, cuerpo: string, secreto: string): string {
  const huella = createHash('sha256').update(cuerpo).digest('hex');
  return `sha256=${createHmac('sha256', secreto)
    .update(`gestor-v1\n${identificador}\n${marca}\n${huella}`)
    .digest('hex')}`;
}

export function autorizarGestor(
  identificador: string | undefined,
  marca: string | undefined,
  firma: string | undefined,
  cuerpo: string,
  secreto: string,
  usados: Map<string, number>,
  ahora = Math.floor(Date.now() / 1000),
): boolean {
  if (!identificador || !/^gestor-[a-f0-9]{32}$/.test(identificador)
    || !marca || !/^[0-9]{10,11}$/.test(marca)
    || !firma || !/^sha256=[a-f0-9]{64}$/.test(firma)) return false;

  const instante = Number(marca);
  if (!Number.isSafeInteger(instante) || Math.abs(ahora - instante) > 60) return false;
  if (usados.has(identificador)) return false;

  const esperada = Buffer.from(firmarGestor(identificador, marca, cuerpo, secreto).slice(7), 'hex');
  const recibida = Buffer.from(firma.slice(7), 'hex');
  if (!timingSafeEqual(esperada, recibida)) return false;

  for (const [clave, tiempo] of usados) {
    if (tiempo < ahora - 120) usados.delete(clave);
  }
  if (usados.size > 1000) return false;
  usados.set(identificador, ahora);
  return true;
}

export function idNuevaSolicitud(): string {
  return `gestor-${randomUUID().replace(/-/g, '')}`;
}
