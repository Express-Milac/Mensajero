import 'dotenv/config';
import { resolve } from 'node:path';
import { validarUrlMensajero } from './configuracion.js';
import { GestorConexiones } from './gestion/gestor-conexiones.js';

const secreto = process.env.MENSAJERO_PASARELA_SECRETO?.trim() ?? '';
if (secreto.length < 32) throw new Error('Secreto HMAC del gestor no configurado.');
const url = validarUrlMensajero(process.env.MENSAJERO_URL ?? '');
const datos = resolve(process.cwd(), process.env.RECOLECTOR_RUTA_DATOS?.trim() || './datos');
const gestor = new GestorConexiones(url, secreto, datos);
let cerrando = false;
const cerrar = async (): Promise<void> => {
  if (cerrando) return;
  cerrando = true;
  await gestor.detener();
  process.exit(0);
};
process.once('SIGTERM', () => { void cerrar(); });
process.once('SIGINT', () => { void cerrar(); });
await gestor.iniciarServidor();
process.stdout.write('[Gestor] Servicio de conexiones listo solo en 127.0.0.1:8787.\n');
