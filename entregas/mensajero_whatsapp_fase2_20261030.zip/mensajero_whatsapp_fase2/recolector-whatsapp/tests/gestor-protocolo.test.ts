import assert from 'node:assert/strict';
import { test } from 'node:test';
import { autorizarGestor, firmarGestor } from '../src/gestion/protocolo.js';

const secreto = 'a'.repeat(64);

test('acepta firma válida y rechaza repetición', () => {
  const marca = String(Math.floor(Date.now() / 1000));
  const id = 'gestor-' + 'b'.repeat(32);
  const cuerpo = JSON.stringify({ clave_conexion: 'c'.repeat(48) });
  const firma = firmarGestor(id, marca, cuerpo, secreto);
  const usados = new Map<string, number>();
  assert.equal(autorizarGestor(id, marca, firma, cuerpo, secreto, usados), true);
  assert.equal(autorizarGestor(id, marca, firma, cuerpo, secreto, usados), false);
});

test('rechaza contenido modificado, firma incorrecta y firma caducada', () => {
  const marca = String(Math.floor(Date.now() / 1000));
  const id = 'gestor-' + 'c'.repeat(32);
  const firma = firmarGestor(id, marca, '{}', secreto);
  assert.equal(autorizarGestor(id, marca, firma, '{"x":1}', secreto, new Map()), false);
  assert.equal(autorizarGestor(id, marca, 'sha256=' + '0'.repeat(64), '{}', secreto, new Map()), false);
  const vieja = String(Number(marca) - 120);
  assert.equal(autorizarGestor(id, vieja, firmarGestor(id, vieja, '{}', secreto), '{}', secreto, new Map()), false);
});
