<?php

namespace App\Http\Controllers\Pasarela;

use App\Http\Controllers\Controller;
use App\Models\ConexionWhatsapp;
use Illuminate\Http\JsonResponse;

class ControladorConexionesHabilitadas extends Controller
{
    /**
     * Solo accesible con firma de la pasarela. Lista para restauración del gestor
     * después de reiniciar el servicio, sin credenciales de sesión de Baileys.
     */
    public function indice(): JsonResponse
    {
        $conexiones = ConexionWhatsapp::query()
            ->where('proveedor', 'recolector_whatsapp')
            ->get(['id', 'clave_conexion', 'metadatos'])
            ->filter(function ($conexion): bool {
                $metadatos = is_array($conexion->metadatos) ? $conexion->metadatos : [];
                return ($metadatos['vinculacion_habilitada'] ?? false) === true;
            })
            ->map(function ($conexion): array {
                return [
                    'id' => (int) $conexion->id,
                    'clave_conexion' => (string) $conexion->clave_conexion,
                ];
            })
            ->values();

        return response()->json(['conexiones' => $conexiones])
            ->header('Cache-Control', 'private, no-store, max-age=0');
    }
}
