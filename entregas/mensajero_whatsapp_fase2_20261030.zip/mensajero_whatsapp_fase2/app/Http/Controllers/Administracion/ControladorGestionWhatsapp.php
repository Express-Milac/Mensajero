<?php

namespace App\Http\Controllers\Administracion;

use App\Http\Controllers\Controller;
use App\Models\ConexionWhatsapp;
use App\Services\WhatsApp\ClienteGestorWhatsapp;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Log;
use RuntimeException;

class ControladorGestionWhatsapp extends Controller
{
    private function conexion(int $id): ConexionWhatsapp
    {
        return ConexionWhatsapp::query()
            ->where('proveedor', 'recolector_whatsapp')
            ->findOrFail($id);
    }

    public function iniciar(int $conexion, ClienteGestorWhatsapp $gestor): RedirectResponse
    {
        $registro = $this->conexion($conexion);

        try {
            $gestor->enviar('POST', '/v1/conexiones/'.$registro->id.'/iniciar', [
                'clave_conexion' => $registro->clave_conexion,
            ]);
        } catch (RuntimeException $error) {
            return back()->withErrors(['gestion' => $error->getMessage()]);
        }

        $metadatos = is_array($registro->metadatos) ? $registro->metadatos : [];
        $metadatos['vinculacion_habilitada'] = true;
        $registro->metadatos = $metadatos;
        $registro->estado = 'conectando';
        $registro->save();
        Log::info('mensajero.whatsapp.vinculacion_solicitada', [
            'conexion_id' => (int) $registro->id, 'usuario_id' => auth()->id(),
        ]);

        return back()->with('estado', 'Vinculación iniciada. Consulta el QR de esta línea.');
    }

    public function detener(int $conexion, ClienteGestorWhatsapp $gestor): RedirectResponse
    {
        $registro = $this->conexion($conexion);
        try {
            $gestor->enviar('POST', '/v1/conexiones/'.$registro->id.'/detener');
        } catch (RuntimeException $error) {
            return back()->withErrors(['gestion' => $error->getMessage()]);
        }

        $metadatos = is_array($registro->metadatos) ? $registro->metadatos : [];
        $metadatos['vinculacion_habilitada'] = false;
        $registro->metadatos = $metadatos;
        $registro->estado = 'desconectado';
        $registro->save();
        Log::info('mensajero.whatsapp.detencion_solicitada', [
            'conexion_id' => (int) $registro->id, 'usuario_id' => auth()->id(),
        ]);

        return back()->with('estado', 'Línea detenida; se conservan las credenciales y los mensajes.');
    }

    public function estado(int $conexion, ClienteGestorWhatsapp $gestor): JsonResponse
    {
        $this->conexion($conexion);
        try {
            $respuesta = $gestor->enviar('GET', '/v1/conexiones/'.$conexion);
            return response()->json($respuesta)->header('Cache-Control', 'private, no-store, max-age=0');
        } catch (RuntimeException $error) {
            return response()->json([
                'estado' => 'gestor_no_disponible',
                'mensaje' => $error->getMessage(),
            ], 503)->header('Cache-Control', 'private, no-store, max-age=0');
        }
    }
}
