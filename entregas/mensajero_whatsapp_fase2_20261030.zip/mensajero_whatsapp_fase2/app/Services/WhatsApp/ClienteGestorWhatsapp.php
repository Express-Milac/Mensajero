<?php

namespace App\Services\WhatsApp;

use Illuminate\Support\Facades\Http;
use RuntimeException;
use Throwable;

class ClienteGestorWhatsapp
{
    /** @return array<string, mixed> */
    public function enviar(string $metodo, string $ruta, array $datos = []): array
    {
        if (! in_array($metodo, ['GET', 'POST'], true)
            || ! preg_match('#^/v1/conexiones/[1-9][0-9]*(?:/(?:iniciar|detener))?$#', $ruta)) {
            throw new RuntimeException('Ruta de gestión no permitida.');
        }

        $secreto = (string) config('mensajero.pasarela_secreto', '');
        if (strlen($secreto) < 32) {
            throw new RuntimeException('La seguridad de gestión no está configurada.');
        }

        $cuerpo = $metodo === 'GET' ? '' : json_encode($datos, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        if (! is_string($cuerpo)) {
            throw new RuntimeException('No fue posible preparar la solicitud.');
        }

        $id = 'gestor-'.bin2hex(random_bytes(16));
        $marca = (string) time();
        $canonico = implode("\n", ['gestor-v1', $id, $marca, hash('sha256', $cuerpo)]);
        $firma = 'sha256='.hash_hmac('sha256', $canonico, $secreto);

        try {
            $respuesta = Http::timeout(5)->withOptions([
                'allow_redirects' => false,
                'connect_timeout' => 2,
            ])->withHeaders([
                'Accept' => 'application/json',
                'Content-Type' => 'application/json',
                'X-Mensajero-Gestor-Id' => $id,
                'X-Mensajero-Gestor-Marca' => $marca,
                'X-Mensajero-Gestor-Firma' => $firma,
            ])->send($metodo, 'http://127.0.0.1:8787'.$ruta, ['body' => $cuerpo]);
        } catch (Throwable $error) {
            // Nunca propagar URL, contenido ni secretos del gestor al navegador.
            throw new RuntimeException('El servicio de conexiones no está disponible.', 0, $error);
        }

        if (! $respuesta->successful()) {
            throw new RuntimeException('El gestor rechazó la operación (HTTP '.$respuesta->status().').');
        }

        $contenido = $respuesta->json();
        if (! is_array($contenido)) {
            throw new RuntimeException('El gestor devolvió una respuesta inválida.');
        }

        return $contenido;
    }
}
